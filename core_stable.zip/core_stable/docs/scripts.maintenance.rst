maintenance Package
===================

:mod:`maintenance` Package
--------------------------

.. automodule:: scripts.maintenance
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`cache` Module
-------------------

.. automodule:: scripts.maintenance.cache
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`compat2core` Module
-------------------------

.. automodule:: scripts.maintenance.compat2core
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`make_i18n_dict` Module
----------------------------

.. automodule:: scripts.maintenance.make_i18n_dict
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`wikimedia_sites` Module
-----------------------------

.. automodule:: scripts.maintenance.wikimedia_sites
    :members:
    :undoc-members:
    :show-inheritance:

