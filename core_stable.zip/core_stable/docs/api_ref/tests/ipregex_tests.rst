=============
ipregex_tests
=============
    Tests in ``tests.ipregex_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.ipregex_tests.PyWikiIpRegexCase
        :members:

