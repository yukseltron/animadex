==========
file_tests
==========
    Tests in ``tests.file_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.file_tests.TestShareFiles
        :members:

