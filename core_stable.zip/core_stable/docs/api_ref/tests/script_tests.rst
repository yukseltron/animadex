============
script_tests
============
    Tests in ``tests.script_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.script_tests.TestScript
        :members:
    .. autofunction:: tests.script_tests.load_tests

