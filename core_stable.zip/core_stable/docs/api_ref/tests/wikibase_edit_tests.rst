===================
wikibase_edit_tests
===================
    Tests in ``tests.wikibase_edit_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.wikibase_edit_tests.TestWikibaseWriteGeneral
        :members:

