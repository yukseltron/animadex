========
ui_tests
========
    Tests in ``tests.ui_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.ui_tests.TestTerminalUI
        :members:

