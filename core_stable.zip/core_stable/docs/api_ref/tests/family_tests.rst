============
family_tests
============
    Tests in ``tests.family_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.family_tests.TestFamily
        :members:
    .. autoclass:: tests.family_tests.TestOldFamilyMethod
        :members:

