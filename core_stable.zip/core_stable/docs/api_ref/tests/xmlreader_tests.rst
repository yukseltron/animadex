===============
xmlreader_tests
===============
    Tests in ``tests.xmlreader_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.xmlreader_tests.XmlReaderTestCase
        :members:

