======================
mediawikiversion_tests
======================
    Tests in ``tests.mediawikiversion_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.mediawikiversion_tests.TestMediaWikiVersion
        :members:

