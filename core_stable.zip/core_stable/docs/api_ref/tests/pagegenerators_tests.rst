====================
pagegenerators_tests
====================
    Tests in ``tests.pagegenerators_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.pagegenerators_tests.TestDryPageGenerators
        :members:
    .. autoclass:: tests.pagegenerators_tests.EdittimeFilterPageGeneratorTestCase
        :members:
    .. autoclass:: tests.pagegenerators_tests.TestRepeatingGenerator
        :members:
    .. autoclass:: tests.pagegenerators_tests.TestPreloadingGenerator
        :members:
    .. autoclass:: tests.pagegenerators_tests.TestDequePreloadingGenerator
        :members:
    .. autoclass:: tests.pagegenerators_tests.TestPreloadingItemGenerator
        :members:
    .. autoclass:: tests.pagegenerators_tests.TestFactoryGenerator
        :members:
    .. autoclass:: tests.pagegenerators_tests.PageGeneratorIntersectTestCase
        :members:
    .. autoclass:: tests.pagegenerators_tests.EnglishWikipediaPageGeneratorIntersectTestCase
        :members:

