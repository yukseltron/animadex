==================
edit_failure_tests
==================
    Tests in ``tests.edit_failure_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.edit_failure_tests.TestActionFailure
        :members:
    .. autoclass:: tests.edit_failure_tests.TestSaveFailure
        :members:
    .. autoclass:: tests.edit_failure_tests.TestWikibaseSaveTest
        :members:

