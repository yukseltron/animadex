==============
dry_site_tests
==============
    Tests in ``tests.dry_site_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.dry_site_tests.TestDrySite
        :members:
    .. autoclass:: tests.dry_site_tests.TestMustBe
        :members:
    .. autoclass:: tests.dry_site_tests.TestNeedVersion
        :members:

