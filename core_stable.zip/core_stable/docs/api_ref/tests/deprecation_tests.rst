=================
deprecation_tests
=================
    Tests in ``tests.deprecation_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.deprecation_tests.DecoratorFullNameTestCase
        :members:
    .. autoclass:: tests.deprecation_tests.DeprecatorTestCase
        :members:

