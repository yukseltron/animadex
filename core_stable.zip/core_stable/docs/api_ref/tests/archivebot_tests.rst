================
archivebot_tests
================
    Tests in ``tests.archivebot_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.archivebot_tests.TestArchiveBot
        :members:

