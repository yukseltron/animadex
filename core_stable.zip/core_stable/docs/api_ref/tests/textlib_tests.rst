=============
textlib_tests
=============
    Tests in ``tests.textlib_tests``:

---------------
Available tests
---------------
    .. autoclass:: tests.textlib_tests.TestCategoryRearrangement
        :members:
    .. autoclass:: tests.textlib_tests.TestFormatCategory
        :members:
    .. autoclass:: tests.textlib_tests.TestFormatInterwiki
        :members:
    .. autoclass:: tests.textlib_tests.TestLocalDigits
        :members:
    .. autoclass:: tests.textlib_tests.TestSectionFunctions
        :members:
    .. autoclass:: tests.textlib_tests.TestTemplatesInCategory
        :members:

