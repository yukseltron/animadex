Installation
------------

.. _installation:

.. note::
   Please see the old documentation at `Manual:Pywikibot/Installation <https://www.mediawiki.org/wiki/Manual:Pywikibot/Installation>`_
