Using pywikibot as library
------------

.. note::
   Please see the old documentation at `Manual:Pywikibot/Create your own script <https://www.mediawiki.org/wiki/Manual:Pywikibot/Create_your_own_script>`_
